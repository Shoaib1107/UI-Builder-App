package com.example.uibuilderapp

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.uibuilderapp.databinding.ActivityUiBuilderBinding
import org.json.JSONArray
import org.json.JSONObject

class UIBuilderActivity : AppCompatActivity() {

    private lateinit var binding: ActivityUiBuilderBinding
    private lateinit var componentAdapter: ComponentAdapter
    private val addedComponents = mutableListOf<UIComponent>()
    private var componentCounter = 0

    companion object {
        const val EXTRA_INITIAL_COMPONENT = "initial_component"
        const val PREFS_NAME = "UIBuilderPrefs"
        const val KEY_SAVED_LAYOUTS = "saved_layouts"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUiBuilderBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        setupClickListeners()
        
        // Handle initial component if passed from MainActivity
        intent.getStringExtra(EXTRA_INITIAL_COMPONENT)?.let { componentName ->
            addComponentToPreview(componentName)
        }
    }

    private fun setupRecyclerView() {
        val components = listOf(
            Component("Button", android.R.drawable.ic_menu_send),
            Component("TextView", android.R.drawable.ic_menu_edit),
            Component("EditText", android.R.drawable.ic_menu_search),
            Component("ImageView", android.R.drawable.ic_menu_gallery)
        )

        componentAdapter = ComponentAdapter(components) { component ->
            addComponentToPreview(component.name)
        }

        binding.rvBuilderComponents.apply {
            layoutManager = LinearLayoutManager(this@UIBuilderActivity)
            adapter = componentAdapter
        }
    }

    private fun setupClickListeners() {
        binding.btnGenerateCode.setOnClickListener {
            generateKotlinCode()
        }

        binding.btnSaveLayout.setOnClickListener {
            saveLayout()
        }
    }

    private fun addComponentToPreview(componentType: String) {
        val viewId = View.generateViewId()
        componentCounter++
        
        when (componentType) {
            "Button" -> {
                val button = Button(this).apply {
                    id = viewId
                    text = getString(R.string.sample_button_text)
                    setPadding(32, 24, 32, 24)
                    setOnClickListener { 
                        Toast.makeText(this@UIBuilderActivity, "Button clicked!", Toast.LENGTH_SHORT).show()
                    }
                }
                binding.llPreviewContainer.addView(button)
                addedComponents.add(UIComponent("Button", "Button${componentCounter}", "text = \"${getString(R.string.sample_button_text)}\""))
            }
            
            "TextView" -> {
                val textView = TextView(this).apply {
                    id = viewId
                    text = getString(R.string.sample_textview_text)
                    textSize = 16f
                    setPadding(16, 16, 16, 16)
                }
                binding.llPreviewContainer.addView(textView)
                addedComponents.add(UIComponent("TextView", "TextView${componentCounter}", "text = \"${getString(R.string.sample_textview_text)}\""))
            }
            
            "EditText" -> {
                val editText = EditText(this).apply {
                    id = viewId
                    hint = getString(R.string.sample_edittext_hint)
                    setPadding(16, 16, 16, 16)
                }
                binding.llPreviewContainer.addView(editText)
                addedComponents.add(UIComponent("EditText", "EditText${componentCounter}", "hint = \"${getString(R.string.sample_edittext_hint)}\""))
            }
            
            "ImageView" -> {
                val imageView = ImageView(this).apply {
                    id = viewId
                    setImageResource(android.R.drawable.ic_menu_gallery)
                    setPadding(16, 16, 16, 16)
                    scaleType = ImageView.ScaleType.CENTER_CROP
                }
                binding.llPreviewContainer.addView(imageView)
                addedComponents.add(UIComponent("ImageView", "ImageView${componentCounter}", "src = android.R.drawable.ic_menu_gallery"))
            }
        }
        
        // Add some spacing between components
        val spacer = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                16
            )
        }
        binding.llPreviewContainer.addView(spacer)
    }

    private fun generateKotlinCode() {
        val codeBuilder = StringBuilder()
        codeBuilder.appendLine("// Generated Kotlin Code for UI Layout")
        codeBuilder.appendLine("val layout = LinearLayout(this).apply {")
        codeBuilder.appendLine("    orientation = LinearLayout.VERTICAL")
        codeBuilder.appendLine("    setPadding(16, 16, 16, 16)")
        codeBuilder.appendLine()
        
        addedComponents.forEach { component ->
            when (component.type) {
                "Button" -> {
                    codeBuilder.appendLine("    val ${component.name} = Button(this).apply {")
                    codeBuilder.appendLine("        ${component.properties}")
                    codeBuilder.appendLine("        setPadding(32, 24, 32, 24)")
                    codeBuilder.appendLine("    }")
                    codeBuilder.appendLine("    addView(${component.name})")
                    codeBuilder.appendLine()
                }
                "TextView" -> {
                    codeBuilder.appendLine("    val ${component.name} = TextView(this).apply {")
                    codeBuilder.appendLine("        ${component.properties}")
                    codeBuilder.appendLine("        textSize = 16f")
                    codeBuilder.appendLine("        setPadding(16, 16, 16, 16)")
                    codeBuilder.appendLine("    }")
                    codeBuilder.appendLine("    addView(${component.name})")
                    codeBuilder.appendLine()
                }
                "EditText" -> {
                    codeBuilder.appendLine("    val ${component.name} = EditText(this).apply {")
                    codeBuilder.appendLine("        ${component.properties}")
                    codeBuilder.appendLine("        setPadding(16, 16, 16, 16)")
                    codeBuilder.appendLine("    }")
                    codeBuilder.appendLine("    addView(${component.name})")
                    codeBuilder.appendLine()
                }
                "ImageView" -> {
                    codeBuilder.appendLine("    val ${component.name} = ImageView(this).apply {")
                    codeBuilder.appendLine("        ${component.properties}")
                    codeBuilder.appendLine("        setPadding(16, 16, 16, 16)")
                    codeBuilder.appendLine("        scaleType = ImageView.ScaleType.CENTER_CROP")
                    codeBuilder.appendLine("    }")
                    codeBuilder.appendLine("    addView(${component.name})")
                    codeBuilder.appendLine()
                }
            }
        }
        
        codeBuilder.appendLine("}")
        
        showCodeDialog(codeBuilder.toString())
    }

    private fun showCodeDialog(code: String) {
        AlertDialog.Builder(this)
            .setTitle("Generated Kotlin Code")
            .setMessage(code)
            .setPositiveButton("OK", null)
            .setNeutralButton("Copy to Clipboard") { _, _ ->
                // Copy to clipboard functionality would go here
                Toast.makeText(this, getString(R.string.code_generated), Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun saveLayout() {
        try {
            val layoutJson = JSONObject()
            val componentsArray = JSONArray()
            
            addedComponents.forEach { component ->
                val componentJson = JSONObject().apply {
                    put("type", component.type)
                    put("name", component.name)
                    put("properties", component.properties)
                }
                componentsArray.put(componentJson)
            }
            
            layoutJson.put("components", componentsArray)
            layoutJson.put("timestamp", System.currentTimeMillis())
            
            // Save to shared preferences
            val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val existingLayouts = prefs.getString(KEY_SAVED_LAYOUTS, "[]")
            val layoutsArray = JSONArray(existingLayouts)
            layoutsArray.put(layoutJson.toString())
            
            prefs.edit()
                .putString(KEY_SAVED_LAYOUTS, layoutsArray.toString())
                .apply()
            
            Toast.makeText(this, getString(R.string.layout_saved), Toast.LENGTH_SHORT).show()
            
        } catch (e: Exception) {
            Toast.makeText(this, "Error saving layout: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    data class UIComponent(
        val type: String,
        val name: String,
        val properties: String
    )
}

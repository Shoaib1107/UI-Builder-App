package com.example.uibuilderapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.uibuilderapp.databinding.ItemComponentBinding

class ComponentAdapter(
    private val components: List<Component>,
    private val onComponentClick: (Component) -> Unit
) : RecyclerView.Adapter<ComponentAdapter.ComponentViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ComponentViewHolder {
        val binding = ItemComponentBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ComponentViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ComponentViewHolder, position: Int) {
        holder.bind(components[position])
    }

    override fun getItemCount(): Int = components.size

    inner class ComponentViewHolder(private val binding: ItemComponentBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(component: Component) {
            binding.tvComponentName.text = component.name
            binding.ivComponentIcon.setImageResource(component.iconRes)
            
            binding.root.setOnClickListener {
                onComponentClick(component)
            }
        }
    }
}

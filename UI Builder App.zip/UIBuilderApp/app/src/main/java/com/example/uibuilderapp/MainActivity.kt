package com.example.uibuilderapp

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.uibuilderapp.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var componentAdapter: ComponentAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        setupClickListeners()
    }

    private fun setupRecyclerView() {
        val components = listOf(
            Component("Button", android.R.drawable.ic_menu_send),
            Component("TextView", android.R.drawable.ic_menu_edit),
            Component("EditText", android.R.drawable.ic_menu_search),
            Component("ImageView", android.R.drawable.ic_menu_gallery)
        )

        componentAdapter = ComponentAdapter(components) { component ->
            // Navigate to UIBuilderActivity with selected component
            val intent = Intent(this, UIBuilderActivity::class.java)
            intent.putExtra(UIBuilderActivity.EXTRA_INITIAL_COMPONENT, component.name)
            startActivity(intent)
        }

        binding.rvComponents.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = componentAdapter
        }
    }

    private fun setupClickListeners() {
        binding.btnStartBuilding.setOnClickListener {
            // Navigate to UIBuilderActivity without initial component
            val intent = Intent(this, UIBuilderActivity::class.java)
            startActivity(intent)
        }
    }
}

data class Component(
    val name: String,
    val iconRes: Int
)
